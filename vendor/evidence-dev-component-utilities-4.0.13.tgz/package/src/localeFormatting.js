/**
 * Locale-aware post-processing for formatted numbers.
 *
 * Evidence formats numbers with ssf, which always uses US-style separators
 * (comma for thousands, period for decimals). This module lets a project opt
 * into a different locale: ssf output is post-processed by swapping the
 * separators that sit between digits, so format codes keep their Excel-style
 * (US) syntax while rendered values follow the configured locale.
 *
 * Usage (e.g. in a project's +layout.svelte):
 *   import { setFormatLocale } from '@evidence-dev/component-utilities/localeFormatting';
 *   setFormatLocale('es-ES'); // 1,234.56 -> 1.234,56
 */

const US_SEPARATORS = { decimal: '.', group: ',' };

let formatLocale = undefined;
let separators = { ...US_SEPARATORS };

/**
 * Derives decimal/group separators for a BCP 47 locale via Intl.
 * @param {string} locale e.g. 'es-ES', 'de-DE', 'en-US'
 * @returns {{decimal: string, group: string}}
 */
function deriveSeparators(locale) {
	const parts = new Intl.NumberFormat(locale).formatToParts(12345.6);
	return {
		decimal: parts.find((p) => p.type === 'decimal')?.value ?? US_SEPARATORS.decimal,
		group: parts.find((p) => p.type === 'group')?.value ?? US_SEPARATORS.group
	};
}

/**
 * Sets the locale used to render formatted numbers site-wide.
 * @param {string | undefined} locale BCP 47 locale (e.g. 'es-ES'), or undefined to reset to US defaults
 * @param {{decimal?: string, group?: string}} [overrides] optional explicit separators, takes precedence over the locale-derived ones
 */
export function setFormatLocale(locale, overrides = undefined) {
	formatLocale = locale;
	separators = locale ? deriveSeparators(locale) : { ...US_SEPARATORS };
	if (overrides?.decimal) separators.decimal = overrides.decimal;
	if (overrides?.group) separators.group = overrides.group;
}

/** @returns {string | undefined} the configured locale, if any */
export function getFormatLocale() {
	return formatLocale;
}

const BETWEEN_DIGITS_SEPARATOR = /(?<=\d)[.,](?=\d)/g;

/**
 * Swaps US-style separators in an ssf-formatted number for the configured
 * locale's separators. Only touches '.' and ',' that sit between two digits,
 * so literal text in format codes (suffixes, currency words) is left alone.
 * @param {string} formatted ssf output for a numeric value
 * @returns {string} the localized string
 */
export function localizeFormattedNumber(formatted) {
	if (formatLocale === undefined || typeof formatted !== 'string') {
		return formatted;
	}
	if (separators.decimal === US_SEPARATORS.decimal && separators.group === US_SEPARATORS.group) {
		return formatted;
	}
	return formatted.replace(BETWEEN_DIGITS_SEPARATOR, (m) =>
		m === '.' ? separators.decimal : separators.group
	);
}
