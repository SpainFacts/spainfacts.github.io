import { describe, it, expect, afterEach } from 'vitest';
import {
	setFormatLocale,
	getFormatLocale,
	localizeFormattedNumber
} from '../localeFormatting.js';
import { formatValue } from '../formatting.js';
import { fallbackFormat } from '../autoFormatting.js';

afterEach(() => {
	setFormatLocale(undefined);
});

describe('localizeFormattedNumber', () => {
	it('is a no-op when no locale is set', () => {
		expect(localizeFormattedNumber('1,234.56')).toBe('1,234.56');
	});

	it('swaps separators for es-ES', () => {
		setFormatLocale('es-ES');
		expect(localizeFormattedNumber('1,234.56')).toBe('1.234,56');
	});

	it('handles thousands-only and decimals-only values', () => {
		setFormatLocale('es-ES');
		expect(localizeFormattedNumber('1,234,567')).toBe('1.234.567');
		expect(localizeFormattedNumber('0.75')).toBe('0,75');
	});

	it('leaves separators outside digit pairs untouched', () => {
		setFormatLocale('es-ES');
		expect(localizeFormattedNumber('1,234.5 pts.')).toBe('1.234,5 pts.');
	});

	it('supports explicit separator overrides', () => {
		setFormatLocale('es-ES', { group: ' ' });
		expect(localizeFormattedNumber('1,234.56')).toBe('1 234,56');
	});

	it('is a no-op for locales that already use US separators', () => {
		setFormatLocale('en-US');
		expect(localizeFormattedNumber('1,234.56')).toBe('1,234.56');
	});

	it('exposes the configured locale', () => {
		setFormatLocale('es-ES');
		expect(getFormatLocale()).toBe('es-ES');
	});
});

describe('formatValue with locale', () => {
	it('localizes explicitly formatted numbers', () => {
		setFormatLocale('es-ES');
		expect(formatValue(1234.56, { formatTag: 'custom', formatCode: '#,##0.00' })).toBe('1.234,56');
	});

	it('localizes currency formats', () => {
		setFormatLocale('es-ES');
		expect(formatValue(1234.5, { formatTag: 'custom', formatCode: '#,##0.00"€"' })).toBe(
			'1.234,50€'
		);
	});

	it('does not localize date formats', () => {
		const dateFormat = { formatTag: 'custom', formatCode: 'mmm d, yyyy', valueType: 'date' };
		const unlocalized = formatValue('2022-01-03', dateFormat);
		setFormatLocale('es-ES');
		expect(formatValue('2022-01-03', dateFormat)).toBe(unlocalized);
		expect(formatValue('2022-01-03', dateFormat)).toMatch(/^Jan \d+, 2022$/);
	});

	it('keeps US formatting when no locale is set', () => {
		expect(formatValue(1234.56, { formatTag: 'custom', formatCode: '#,##0.00' })).toBe('1,234.56');
	});
});

describe('fallbackFormat with locale', () => {
	it('uses the configured locale for unformatted numbers', () => {
		setFormatLocale('es-ES');
		expect(fallbackFormat(1234.56)).toBe('1234,56');
	});
});
